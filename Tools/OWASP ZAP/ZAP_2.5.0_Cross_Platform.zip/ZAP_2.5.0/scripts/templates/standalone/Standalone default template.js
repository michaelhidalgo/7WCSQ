// Standalone scripts have no template.
// They are only evaluated when you run them. 

